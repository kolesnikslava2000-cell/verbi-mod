package net.verbi;

import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.text.Text;

public class CustomGuiMenu extends Screen {

    public CustomGuiMenu() {
        super(Text.literal("Verbi Menu"));
    }

    @Override
    protected void init() {
        this.addDrawableChild(ButtonWidget.builder(Text.literal("Кнопка Verbi"), button -> {
            if (this.client != null && this.client.player != null) {
                this.client.player.sendMessage(Text.literal("Привет от мода Verbi!"), false);
                this.close();
            }
        })
        .dimensions(this.width / 2 - 100, this.height / 2 - 10, 200, 20)
        .build());
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        this.renderBackground(context, mouseX, mouseY, delta);
        context.drawCenteredTextWithShadow(this.textRenderer, this.title, this.width / 2, 20, 0xFFFFFF);
        super.render(context, mouseX, mouseY, delta);
    }

    @Override
    public boolean shouldPauseGame() {
        return false;
    }
}
